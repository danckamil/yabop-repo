<addon id="plugin.video.yabopreborn"  
       name="YABoP Reborn"  
       version="1.0.0">  
  
</addon>  
